gcc main.c ADS.c BHI260AP.c shared_memory.c -lmraa -lm
